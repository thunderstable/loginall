<template>
  <div class="container" >
    <header class="jumbotron" style="height:100vh;background-color:#E7E9EA">
      <div class="h3 text-center">
       Manage Users
      </div>
       <div class="h6 text-center">
        Water Treat
      </div>



      <div class="row justify-content-end">
       
          <div class="col-3">
          <input type="search" id="form1" class="form-control" />
      
        </div>
     <button class="btn bg-secondary">Search </button>
      
      </div>
      <table style="width:100% " class="mt-5">
        <tr class="text-center border ">
          <td style="width:200px" class="text-center">
            <h4>User</h4>
          </td>
          <td style="width:200px" class="text-center">
            <h4>Email</h4>
          </td>
          <td style="width:200px" class="text-center">
            <h4>Roles</h4>
          </td>
          <td style="width:200px" class="text-center">
            <h4>Edit</h4>
          </td>
        </tr>
      </table>
      <div v-for="item in items" :key="item.message">
        <!-- {{ item.message }} -->
        <table style="width:100%" class="mt-2">
          <tr>
            <td style="width:200px" class="text-center">{{ item.message[0] }}</td>
            <td style="width:200px" class="text-center">{{ item.message[1] }}</td>
            <td style="width:200px" class="text-center"><form action="/action_page.php">
  <select name="cars" id="cars">
    <option value="volvo">user</option>
    <option value="saab">moderator</option>
    <option value="opel">admin</option>
  </select>
</form></td>
            <td style="width:200px" class="text-center"><button class="btn " style="background-color:#56A0C4">Confirm Edit</button> &nbsp;<button class="btn" style="background-color:#D56A6A">Delete</button></td>
       
          </tr>
        </table>
      </div>
      <!-- <h3>{{ content }}</h3> -->
    </header>
    <body>


      <!-- <table>
  <tr>
    <th>Company</th>
    <th>Contact</th>
    <th>Country</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Ernst Handel</td>
    <td>Roland Mendel</td>
    <td>Austria</td>
  </tr>
  <tr>
    <td>Island Trading</td>
    <td>Helen Bennett</td>
    <td>UK</td>
  </tr>
  <tr>
    <td>Laughing Bacchus Winecellars</td>
    <td>Yoshi Tannamuri</td>
    <td>Canada</td>
  </tr>
  <tr>
    <td>Magazzini Alimentari Riuniti</td>
    <td>Giovanni Rovelli</td>
    <td>Italy</td>
  </tr>
</table> -->
    </body>
  </div>
</template>

<script>
  import UserService from "../services/user.service";

  export default {
    name: "Admin",
    data() {

      return {
        content: "",
        aaa: 1,
        items: [{
            message: ["sgiot", "sgiot@gmail.com" , "admin"]
          },
                {
            message: ["moder1", "moderator@gmail.com", "moderator"]
          },
          {
            message: ["abc", "abc@gmail.com", "user"]
          },
     {
            message: ["abc1", "abc1@gmail.com", "user"]
          },
               {
            message: ["abc2", "abc2@gmail.com", "user"]
          },
             {
            message: ["abc3", "abc3@gmail.com", "user"]
          },
               {
            message: ["abc4", "abc4@gmail.com", "user"]
          },
        ]
      };
    },
    mounted() {
      UserService.getAdminBoard().then(
        (response) => {
          this.content = response.data;
        },
        (error) => {
          this.content =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
        }
      );
    },
  };
</script>

<style>

</style>